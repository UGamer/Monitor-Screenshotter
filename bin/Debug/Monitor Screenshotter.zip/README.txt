To use:
=============================
Just run the exe.
Alternatively, you can use a batch file (.bat) to run the exe and also add a number to determine which monitor to screenshot. (ex: 0 for main monitor, 1 for 2nd monitor, etc.)